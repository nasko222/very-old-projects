﻿Class Class2

    Sub Main() Handles Me.Load

        Me.Text = "Hello World 3.0 on ClassApplication"
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle



        Label1.Left = 20
        Label1.Top = 40
        Label1.Text = "nasko222 the best developer ever :D"

    End Sub

    Sub Label1_ClickEvent() Handles Label1.Click

        MessageBox.Show("bai bai")
        MessageBox.Show("DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!, DEVELOPERS!!!")

        End
    End Sub

End Class